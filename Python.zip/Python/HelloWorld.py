#this is a comment

#my ID number
ID_Number = 11111111111

#my first name
first_name="Test Case"

#my age
Age= 23
