Python 3.8.5 (tags/v3.8.5:580fbb0, Jul 20 2020, 15:43:08) [MSC v.1926 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========== RESTART: C:/Users/Molin Ncube/Desktop/Python/PythonTask.py ==========
Please enter your name: 
Anna
Please enter your surname: 
Black
Please enter your age: 
25
Please enter mark for Maths: 
60
Please enter mark for Science: 
65
Please enter mark for Engineering: 
70
Please enter mark for Technology: 
50
Student Name is :
 Anna
Student Surname is :
 Black
The total average mark is :
 61
Welldone, you have passed
>>> 
>>> 
========== RESTART: C:/Users/Molin Ncube/Desktop/Python/PythonTask.py ==========
Please enter your name: 
Bongani
Please enter your surname: 
Ndlovu
Please enter your age: 
24
Please enter mark for Maths: 
70
Please enter mark for Science: 
58
Please enter mark for Engineering: 
60
Please enter mark for Technology: 
54
Student Name is :
 Bongani
Student Surname is :
 Ndlovu
The total average mark is :
 60
Welldone, you have passed
>>> 
========== RESTART: C:/Users/Molin Ncube/Desktop/Python/PythonTask.py ==========
Please enter your name: 
Mbali
Please enter your surname: 
Mogale
Please enter your age: 
30
Please enter mark for Maths: 
70
Please enter mark for Science: 
75
Please enter mark for Engineering: 
78
Please enter mark for Technology: 
68
Student Name is :
 Mbali
Student Surname is :
 Mogale
The total average mark is :
 72
Welldone, you have passed
>>> 